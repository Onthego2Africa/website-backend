
<?php $__currentLoopData = $parameters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $parameter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(!empty($parameter['__fields'])): ?>
<p>
<details>
<summary>
<?php $__env->startComponent('scribe::components.field-details', [
  'name' => $parameter['name'],
  'type' => $parameter['type'] ?? 'string',
  'required' => $parameter['required'] ?? false,
  'description' => $parameter['description'] ?? '',
  'endpointId' => $endpointId,
  'hasChildren' => true,
  'component' => 'body',
]); ?>
<?php echo $__env->renderComponent(); ?>
</summary>
<br>
<?php $__currentLoopData = $parameter['__fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subfieldName => $subfield): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(!empty($subfield['__fields'])): ?>
<?php $__env->startComponent('scribe::partials.body-parameters', ['parameters' => [$subfieldName => $subfield], 'endpointId' => $endpointId,]); ?>
<?php echo $__env->renderComponent(); ?>
<?php else: ?>
<p>
<?php $__env->startComponent('scribe::components.field-details', [
  'name' => $subfield['name'],
  'type' => $subfield['type'] ?? 'string',
  'required' => $subfield['required'] ?? false,
  'description' => $subfield['description'] ?? '',
  'endpointId' => $endpointId,
  'hasChildren' => false,
  'component' => 'body',
]); ?>
<?php echo $__env->renderComponent(); ?>
</p>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</details>
</p>
<?php else: ?>
<p>
<?php $__env->startComponent('scribe::components.field-details', [
  'name' => $parameter['name'],
  'type' => $parameter['type'] ?? 'string',
  'required' => $parameter['required'] ?? false,
  'description' => $parameter['description'] ?? '',
  'endpointId' => $endpointId,
  'hasChildren' => false,
  'component' => 'body',
]); ?>
<?php echo $__env->renderComponent(); ?>
</p>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\xampp\htdocs\onthego-api\vendor\knuckleswtf\scribe\src/../resources/views//partials/body-parameters.blade.php ENDPATH**/ ?>