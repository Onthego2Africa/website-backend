# <?php echo $groupName; ?>

<?php echo $groupDescription; ?>


<?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo $route['output']; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\xampp\htdocs\onthego-api\vendor\knuckleswtf\scribe\src/../resources/views//partials/group.blade.php ENDPATH**/ ?>