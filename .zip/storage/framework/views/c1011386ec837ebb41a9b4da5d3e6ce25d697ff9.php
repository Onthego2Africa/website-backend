## <?php echo e($route['metadata']['title'] ?: $route['uri']); ?>


<?php $__env->startComponent('scribe::components.badges.auth', ['authenticated' => $route['metadata']['authenticated']]); ?>
<?php echo $__env->renderComponent(); ?>

<?php echo $route['metadata']['description'] ?: ''; ?>


> Example request:

<?php $__currentLoopData = $settings['languages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->make("scribe::partials.example-requests.$language", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if(in_array('GET',$route['methods']) || (isset($route['showresponse']) && $route['showresponse'])): ?>
<?php $__currentLoopData = $route['responses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
> Example response (<?php echo e($response['description'] ?? $response['status']); ?>):

```json
<?php if(is_object($response['content']) || is_array($response['content'])): ?>
<?php echo json_encode($response['content'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE); ?>

<?php elseif(is_string($response['content']) && \Str::startsWith($response['content'], "<<binary>>")): ?>
<Binary data> - <?php echo e(str_replace("<<binary>>","",$response['content'])); ?>

<?php elseif($response['status'] == 204): ?>
<Empty response>
<?php elseif(is_string($response['content']) && json_decode($response['content']) == null && $response['content'] !== null): ?>

<?php echo $response['content']; ?>

<?php else: ?>
<?php echo json_encode(json_decode($response['content']), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE); ?>

<?php endif; ?>
```
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<div id="execution-results-<?php echo e($endpointId); ?>" hidden>
    <blockquote>Received response<span id="execution-response-status-<?php echo e($endpointId); ?>"></span>:</blockquote>
    <pre class="json"><code id="execution-response-content-<?php echo e($endpointId); ?>"></code></pre>
</div>
<div id="execution-error-<?php echo e($endpointId); ?>" hidden>
    <blockquote>Request failed with error:</blockquote>
    <pre><code id="execution-error-message-<?php echo e($endpointId); ?>"></code></pre>
</div>
<form id="form-<?php echo e($endpointId); ?>" data-method="<?php echo e($route['methods'][0]); ?>" data-path="<?php echo e($route['uri']); ?>" data-authed="<?php echo e($route['metadata']['authenticated'] ? 1 : 0); ?>" data-hasfiles="<?php echo e(count($route['fileParameters'])); ?>" data-headers='<?php echo json_encode($route['headers'], 15, 512) ?>' onsubmit="event.preventDefault(); executeTryOut('<?php echo e($endpointId); ?>', this);">
<h3>
    Request&nbsp;&nbsp;&nbsp;
    <?php if($settings['interactive']): ?>
    <button type="button" style="background-color: #8fbcd4; padding: 5px 10px; border-radius: 5px; border-width: thin;" id="btn-tryout-<?php echo e($endpointId); ?>" onclick="tryItOut('<?php echo e($endpointId); ?>');">Try it out ⚡</button>
    <button type="button" style="background-color: #c97a7e; padding: 5px 10px; border-radius: 5px; border-width: thin;" id="btn-canceltryout-<?php echo e($endpointId); ?>" onclick="cancelTryOut('<?php echo e($endpointId); ?>');" hidden>Cancel</button>&nbsp;&nbsp;
    <button type="submit" style="background-color: #6ac174; padding: 5px 10px; border-radius: 5px; border-width: thin;" id="btn-executetryout-<?php echo e($endpointId); ?>" hidden>Send Request 💥</button>
    <?php endif; ?>
</h3>
<?php $__currentLoopData = $route['methods']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p>
<?php $__env->startComponent('scribe::components.badges.http-method', ['method' => $method]); ?><?php echo $__env->renderComponent(); ?> <b><code><?php echo e($route['uri']); ?></code></b>
</p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if($route['metadata']['authenticated'] && $auth['location'] === 'header'): ?>
<p>
<label id="auth-<?php echo e($endpointId); ?>" hidden><?php echo e($auth['name']); ?> header: <b><code><?php echo e($auth['prefix']); ?></code></b><input type="text" name="<?php echo e($auth['name']); ?>" data-prefix="<?php echo e($auth['prefix']); ?>" data-endpoint="<?php echo e($endpointId); ?>" data-component="header"></label>
</p>
<?php endif; ?>
<?php if(count($route['urlParameters'])): ?>
<h4 class="fancy-heading-panel"><b>URL Parameters</b></h4>
<?php $__currentLoopData = $route['urlParameters']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute => $parameter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p>
<?php $__env->startComponent('scribe::components.field-details', [
  'name' => $parameter['name'],
  'type' => $parameter['type'] ?? 'string',
  'required' => $parameter['required'] ?? true,
  'description' => $parameter['description'],
  'endpointId' => $endpointId,
  'component' => 'url',
]); ?>
<?php echo $__env->renderComponent(); ?>
</p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php if(count($route['queryParameters'])): ?>
<h4 class="fancy-heading-panel"><b>Query Parameters</b></h4>
<?php $__currentLoopData = $route['queryParameters']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute => $parameter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p>
<?php $__env->startComponent('scribe::components.field-details', [
  'name' => $parameter['name'],
  'type' => $parameter['type'] ?? 'string',
  'required' => $parameter['required'] ?? true,
  'description' => $parameter['description'],
  'endpointId' => $endpointId,
  'component' => 'query',
]); ?>
<?php echo $__env->renderComponent(); ?>
</p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php if(count($route['nestedBodyParameters'])): ?>
<h4 class="fancy-heading-panel"><b>Body Parameters</b></h4>
<?php $__env->startComponent('scribe::partials.body-parameters', ['parameters' => $route['nestedBodyParameters'], 'endpointId' => $endpointId,]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
</form>

<?php if(count($route['responseFields'] ?? [])): ?>
### Response
<h4 class="fancy-heading-panel"><b>Response Fields</b></h4>
<?php $__currentLoopData = $route['responseFields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p>
<?php $__env->startComponent('scribe::components.field-details', [
  'name' => $field['name'],
  'type' => $field['type'],
  'required' => true,
  'description' => $field['description'],
  'isInput' => false,
]); ?>
<?php echo $__env->renderComponent(); ?>
</p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\onthego-api\vendor\knuckleswtf\scribe\src/../resources/views//partials/endpoint.blade.php ENDPATH**/ ?>