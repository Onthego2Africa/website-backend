title: <?php echo e($settings['title']); ?>


language_tabs:
<?php $__currentLoopData = $settings['languages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
- <?php echo e($language); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

includes:
- "./prepend.md"
- "./authentication.md"
- "./groups/*"
- "./errors.md"
- "./append.md"

logo: <?php echo e($settings['logo'] ?? false); ?>


toc_footers:
<?php if($showPostmanCollectionButton): ?>
- <a href="<?php echo e($postmanCollectionLink); ?>">View Postman collection</a>
<?php endif; ?>
<?php if($showOpenAPISpecButton): ?>
- <a href="<?php echo e($openAPISpecLink); ?>">View OpenAPI (Swagger) spec</a>
<?php endif; ?>
- <a href='http://github.com/knuckleswtf/scribe'>Documentation powered by Scribe ✍</a>
<?php /**PATH C:\xampp\htdocs\onthego-api\vendor\knuckleswtf\scribe\src/../resources/views//partials/frontmatter.blade.php ENDPATH**/ ?>